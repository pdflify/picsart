"use strict";
exports.id = 145;
exports.ids = [145];
exports.modules = {

/***/ 5145:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ToolBar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/img/PicsArt_All_in_One_Editor_Filters.webp
/* harmony default export */ const PicsArt_All_in_One_Editor_Filters = ({"src":"/_next/static/media/PicsArt_All_in_One_Editor_Filters.af55aad1.webp","height":627,"width":1080,"blurDataURL":"data:image/webp;base64,UklGRl4AAABXRUJQVlA4IFIAAADQAQCdASoIAAUAAkA4JYgCdADdRkbQAAD9v/LI3/hS4zSTXotN5G1yeJAjYsNsDHOYpebeo0cs5gn5S3PYW1M7LXLkQwHvuAQZnXG7m2s5ygAA","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/components/Icons/ToolBar.tsx




class ToolBar extends external_react_.Component {
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("figure", {
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                alt: "PicsArt Mod APK EditingBar image",
                src: PicsArt_All_in_One_Editor_Filters,
                placeholder: "blur",
                width: 191,
                height: 108,
                sizes: "100vw",
                style: {
                    width: "100%",
                    height: "auto"
                }
            })
        });
    }
}


/***/ })

};
;