"use strict";
exports.id = 26;
exports.ids = [26];
exports.modules = {

/***/ 5026:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ EditingBar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/img/PicsArt-editing-bar.webp
/* harmony default export */ const PicsArt_editing_bar = ({"src":"/_next/static/media/PicsArt-editing-bar.a5d55590.webp","height":58,"width":1024,"blurDataURL":"data:image/webp;base64,UklGRiwAAABXRUJQVlA4ICAAAAAwAQCdASoIAAEAAkA4JaQAA3AA/vZO3AO8ReJfjgAAAA==","blurWidth":8,"blurHeight":1});
;// CONCATENATED MODULE: ./src/components/Icons/EditingBar.tsx




class EditingBar extends external_react_.Component {
    render() {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "py-6 lg:py-12 flex items-center px-6",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "text-center mx-auto inline-block",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "z-1 relative inline-flex justify-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    alt: "PicsArt Mod APK EditingBar image",
                                    src: PicsArt_editing_bar,
                                    placeholder: "blur",
                                    width: 191,
                                    height: 108,
                                    sizes: "100vw",
                                    style: {
                                        width: "100%",
                                        height: "auto"
                                    }
                                })
                            })
                        }),
                        "  "
                    ]
                }),
                "  "
            ]
        });
    }
}


/***/ })

};
;