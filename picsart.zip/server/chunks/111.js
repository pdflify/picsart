"use strict";
exports.id = 111;
exports.ids = [111];
exports.modules = {

/***/ 5111:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layouts_MobileNav)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/siteNavigationLink.ts
const siteNavigationLink = [
    {
        name: "Home",
        href: "/#"
    },
    {
        name: "Download",
        href: "/#",
        target: "_blank"
    },
    {
        name: "Fonts",
        href: "/#"
    },
    {
        name: "More...",
        href: "/#"
    }
];
/* harmony default export */ const components_siteNavigationLink = (siteNavigationLink);

;// CONCATENATED MODULE: ./src/components/layouts/MobileNav.tsx




const MobileNav = ()=>{
    const [navShow, setNavShow] = (0,external_react_.useState)(false);
    const onToggleNav = ()=>{
        setNavShow((status)=>{
            if (status) {
                document.body.style.overflow = "auto";
            } else {
                // Prevent scrolling
                document.body.style.overflow = "hidden";
            }
            return !status;
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "md:hidden",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                className: "h-10 w-10",
                "aria-label": "Toggle Menu",
                onClick: onToggleNav,
                children: "☰"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `fixed top-0 left-0 z-10 h-full w-full transform bg-gray-200 opacity-95 duration-300 ease-in-out dark:bg-gray-800 ${navShow ? "translate-x-0" : "translate-x-full"}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "button",
                            className: "mr-6 mt-2 h-10 w-10",
                            "aria-label": "Toggle Menu",
                            onClick: onToggleNav,
                            children: "✕"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                        className: "mt-4",
                        children: components_siteNavigationLink.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: item.href,
                                target: item.target,
                                className: "py-1 px-4 flex hover:text-green-600",
                                children: item.name
                            }, item.name))
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layouts_MobileNav = (MobileNav);


/***/ })

};
;