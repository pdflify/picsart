"use strict";
exports.id = 277;
exports.ids = [277];
exports.modules = {

/***/ 2277:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ WindowsFeature)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/img/windows-feature.webp
/* harmony default export */ const windows_feature = ({"src":"/_next/static/media/windows-feature.514bc673.webp","height":573,"width":1080,"blurDataURL":"data:image/webp;base64,UklGRj4AAABXRUJQVlA4IDIAAADQAQCdASoIAAQAAkA4JZwCdAEO+zNNAAD+9v4Z4uZasINrmB6eo5ffOEC2V8bkmrjgAA==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./src/components/Icons/WindowsFeature.tsx




class WindowsFeature extends external_react_.Component {
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("figure", {
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                alt: "PicsArt Mod APK Icon",
                src: windows_feature,
                placeholder: "blur",
                width: 1080,
                height: 573,
                sizes: "100vw",
                style: {
                    width: "100%",
                    height: "auto"
                }
            })
        });
    }
}


/***/ })

};
;