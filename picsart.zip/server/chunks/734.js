"use strict";
exports.id = 734;
exports.ids = [734];
exports.modules = {

/***/ 3734:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AppFigure)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/img/picsart-mod-apk.webp
/* harmony default export */ const picsart_mod_apk = ({"src":"/_next/static/media/picsart-mod-apk.5e2435ab.webp","height":150,"width":150,"blurDataURL":"data:image/webp;base64,UklGRsIAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSEEAAAAAACix9PSxKQAo7//FxP/vKbH/kmBZkv+x9P9L3t9R//T0/0ouMrn/9LH/SuT3//+xKe/D+v//7ygAKbHz87EoAABWUDggWgAAADACAJ0BKggACAACQDglsAJ0ugADN5hUiZWAAPltnY7/CbwHfj6lMGqlOufzqmhkBijA5AP4nNARgM0v6Mg9EZUWvFU8+5K4GhF9V8XcOf31qmHZG7GtSLQwAA==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/components/Icons/AppFigure.tsx




class AppFigure extends external_react_.Component {
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("figure", {
            className: "h-36 w-36",
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                alt: "PicsArt Mod APK Icon",
                src: picsart_mod_apk,
                placeholder: "blur",
                width: 150,
                height: 150,
                sizes: "100vw",
                style: {
                    width: "100%",
                    height: "auto"
                }
            })
        });
    }
}


/***/ })

};
;