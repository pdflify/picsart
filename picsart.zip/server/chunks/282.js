"use strict";
exports.id = 282;
exports.ids = [282];
exports.modules = {

/***/ 6282:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ WindowsIcon)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/img/windows-icon.webp
/* harmony default export */ const windows_icon = ({"src":"/_next/static/media/windows-icon.f519421a.webp","height":200,"width":200,"blurDataURL":"data:image/webp;base64,UklGRrYAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSEEAAAAAABI1Nn2jyNnd//+b////6+v//5z////rvs7MfMjGxLPK29mC0tHRwOr//5z////r0f3/nP///+sACCkubpK2yABWUDggTgAAAJACAJ0BKggACAACQDglqAJ0ugH4AANSmmFwF7wAAP5+qN8GWrHp7D/izr+3SZCMj7MTCGFq8eCf/nEugVnb/gf/9jOpPp3fozqT+SQAAA==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/components/Icons/WindowsIcon.tsx




class WindowsIcon extends external_react_.Component {
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("figure", {
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                alt: "PicsArt Mod APK Icon",
                src: windows_icon,
                placeholder: "blur",
                width: 150,
                height: 150,
                sizes: "100vw",
                style: {
                    width: "100%",
                    height: "auto"
                }
            })
        });
    }
}


/***/ })

};
;