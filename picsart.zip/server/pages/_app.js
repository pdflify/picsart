(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5126:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/styles/globals.css
var globals = __webpack_require__(108);
;// CONCATENATED MODULE: external "next/amp"
const amp_namespaceObject = require("next/amp");
// EXTERNAL MODULE: external "next-themes"
var external_next_themes_ = __webpack_require__(1162);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/layouts/NavBar.tsx



//import ThemeSwitch from './ThemeSwitch'
//import { useRouter } from 'next/router'
//import { useTranslation, Trans } from 'next-i18next'
const DynamicMobileNav = dynamic_default()(()=>__webpack_require__.e(/* import() */ 111).then(__webpack_require__.bind(__webpack_require__, 5111)), {
    loadableGenerated: {
        modules: [
            "..\\components\\layouts\\NavBar.tsx -> " + "./MobileNav"
        ]
    },
    ssr: false
});
const DynamicThemeSwitch = dynamic_default()(()=>__webpack_require__.e(/* import() */ 454).then(__webpack_require__.bind(__webpack_require__, 8454)), {
    loadableGenerated: {
        modules: [
            "..\\components\\layouts\\NavBar.tsx -> " + "./ThemeSwitch"
        ]
    },
    ssr: false
});
//const DynamicLangChang = dynamic(() => import('./LangChang'),
//{ ssr: false })
const APP_LOGO_NAME = "PicsArt Mod Apk";
function NavBar() {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    "aria-hidden": "true",
                    className: "absolute top-0 left-0 right-0 h-72 z-[-1] opacity-20 pointer-events-none",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            width: "100%",
                            height: "100%",
                            animationDelay: "0.6s",
                            animationDuration: "1s"
                        },
                        className: "fade-in",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("canvas", {
                            height: 576,
                            width: 686,
                            style: {
                                width: 343,
                                height: 288
                            }
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "h-1 bg-gradient-to-r from-[#9867f0] to-[#ed4e50]"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("header", {
                    className: "p-4",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: `${"http://localhost:3000"}`,
                                    children: APP_LOGO_NAME
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                className: "space-x-4 text-sm text-gray-600",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DynamicThemeSwitch, {})
                            })
                        ]
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/components/layouts/FooterApp.tsx


const footernav = [
    {
        name: "Privacy Policy",
        href: "/yyt"
    },
    {
        name: "Terms",
        href: "/#jhj"
    },
    {
        name: "Contact",
        href: "/about"
    },
    {
        name: "Advertisement",
        href: "/#ytyt",
        target: "_blank"
    }
];
function FooterApp() {
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: " bg-gray-100 dark:bg-slate-800 lg:px-28",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center justify-center lg:justify-between text-center lg:text-left flex-wrap py-4 w-full max-w-screen-xl mx-auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-full lg:w-1/2 mb-2 lg:mb-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full block lg:flex lg:items-center lg:w-auto",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "lg:grow",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "text-gray-800 dark:text-gray-300 block lg:inline-block mb-2 lg:mb-0 lg:mr-8",
                                    children: [
                                        "\xa9 ",
                                        new Date().getFullYear(),
                                        " ~ ",
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: `${"http://localhost:3000"}`,
                                            children: "PicsArt Mod APK"
                                        })
                                    ]
                                }),
                                footernav.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: item.href,
                                        target: item.target,
                                        className: "px-1 hover:text-orange-400 text-gray-900 dark:text-gray-300",
                                        children: item.name
                                    }, item.name))
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center lg:justify-end w-full lg:w-1/2"
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/components/layouts/MainLayout.tsx


const MainLayout = ({ children  })=>{
    return /*#__PURE__*/ _jsx("div", {
        className: "container p-1 lg:px-20 mx-auto",
        children: /*#__PURE__*/ _jsx("div", {
            className: "flex flex-row flex-wrap py-4",
            children: children
        })
    });
};
/* harmony default export */ const layouts_MainLayout = ((/* unused pure expression or super */ null && (MainLayout)));

;// CONCATENATED MODULE: external "styled-jsx/style"
const style_namespaceObject = require("styled-jsx/style");
;// CONCATENATED MODULE: ./src/components/layouts/AmpHeader.tsx



function AmpHeader_AmpHeader() {
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsx("header", {
            className: "main-header",
            children: /*#__PURE__*/ _jsx("nav", {
                className: "blog-title",
                children: /*#__PURE__*/ _jsx(Link, {
                    href: `${"http://localhost:3000"}`,
                    children: "PicsArt Mod APK"
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/components/layouts/AmpFooter.tsx



function AmpFooter_AmpFooter() {
    return /*#__PURE__*/ _jsx("footer", {
        className: "site-footer clearfix",
        children: /*#__PURE__*/ _jsxs("section", {
            className: "copyright",
            children: [
                /*#__PURE__*/ _jsx(Link, {
                    href: `${"http://localhost:3000"}`,
                    children: /*#__PURE__*/ _jsx("span", {
                        itemProp: "copyrightHolder",
                        itemScope: true,
                        itemType: "https://schema.org/Organization",
                        children: /*#__PURE__*/ _jsx("span", {
                            itemProp: "name",
                            children: "PicsArt Mod APK"
                        })
                    })
                }),
                " \xa9 ",
                /*#__PURE__*/ _jsx("span", {
                    itemProp: "copyrightYear",
                    children: new Date().getFullYear()
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/components/layouts/AmpLayout.tsx





function AmpLayout({ children  }) {
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx(AmpHeader, {}),
            children,
            /*#__PURE__*/ _jsx(AmpFooter, {}),
            _jsx(_JSXStyle, {
                id: "f9ee8ac6366707b5",
                children: 'html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}d-body-text-color{text-opacity:1;color:rgba(0,53,67,var(text-opacity))}d-body-bg{bg-opacity:1;background-color:rgba(255,255,255,var(bg-opacity))}.svgb{background:-webkit-linear-gradient(#e66465,#9198e5);background:-moz-linear-gradient(#e66465,#9198e5);background:-o-linear-gradient(#e66465,#9198e5);background:linear-gradient(#e66465,#9198e5)}body{font-family:"DM Sans",sans-serif;font-weight:500;margin:0}.cookie-disclaimer{background:#fff;text-align:center;color:#000;border-top:.5px solid#000;font-size:15px}.literacy-number{font-size:.14rem}.population-number{font-size:.6rem}.area-code{font-size:1.2rem;text-anchor:middle}.area-name{font-size:.4rem;text-anchor:middle}.area-km2{font-size:.3rem;text-anchor:middle}.amp-table{overflow-x:scroll}.amp-breadcrumb{font-size:1.3rem;margin:0;padding:0}.amp-breadcrumb li{margin:0;padding:0;display:inline-block}.mx1{padding:0 .5rem;color:#444}.box-author{margin-top:1px;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex}.push-date{margin-left:auto}article,aside,details,figcaption,figure,footer,header,main,menu,nav,section,summary{display:block}audio,canvas,progress,video{display:inline-block;vertical-align:baseline}audio:not([controls]){display:none;height:0}[hidden],template{display:none}a{background-color:transparent}a:active,a:hover{outline:0}abbr[title]{border-bottom:1px dotted}b,strong{font-weight:bold}dfn{font-style:italic}h1{margin:.67em 0;font-size:2em}mark{background:#ff0;color:#000}small{font-size:80%}sub,sup{position:relative;vertical-align:baseline;font-size:75%;line-height:0}sup{top:-.5em}sub{bottom:-.25em}img{border:0}amp-img{border:0}svg:not(:root){overflow:hidden}figure{margin:1em 40px}hr{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;height:0}pre{overflow:auto}code,kbd,pre,samp{font-family:monospace,monospace;font-size:1em}button,input,optgroup,select,textarea{margin:0;color:inherit;font:inherit}button{overflow:visible}button,select{text-transform:none}button,html input[type="button"],input[type="reset"],input[type="submit"]{cursor:pointer;-webkit-appearance:button}button[disabled],html input[disabled]{cursor:default}button::-moz-focus-inner,input::-moz-focus-inner{padding:0;border:0}input{line-height:normal}input[type="checkbox"],input[type="radio"]{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:0}input[type="number"]::-webkit-inner-spin-button,input[type="number"]::-webkit-outer-spin-button{height:auto}input[type="search"]{-webkit-appearance:textfield}input[type="search"]::-webkit-search-cancel-button,input[type="search"]::-webkit-search-decoration{-webkit-appearance:none}fieldset{margin:0 2px;padding:.35em .625em .75em;border:1px solid#c0c0c0}legend{padding:0;border:0}textarea{overflow:auto}optgroup{font-weight:bold}table{border-spacing:0;border-collapse:collapse}td,th{padding:0}html{max-height:100%;height:100%;font-size:62.5%;-webkit-tap-highlight-color:rgba(0,0,0,0)}body{max-height:100%;height:100%;color:#2a2a40;background:#eeeef0;letter-spacing:.01rem;font-family:system-ui,-apple-system,"Segoe UI",Roboto,"DM Sans","Helvetica Neue","Noto Sans","Liberation Sans",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";font-size:1.8rem;font-weight:400;line-height:1.75em;text-rendering:geometricPrecision;-webkit-font-feature-settings:"kern"1;-moz-font-feature-settings:"kern"1;-o-font-feature-settings:"kern"1}::-moz-selection{background:#d6edff}::selection{background:#d6edff}h1,h2,h3,h4,h5,h6{margin:0 0 .3em 0;color:#0a0a23;line-height:1.15em;font-family:"DM Sans",sans-serif;font-weight:500;text-rendering:geometricPrecision;-webkit-font-feature-settings:"dlig"1,"liga"1,"lnum"1,"kern"1;-moz-font-feature-settings:"dlig"1,"liga"1,"lnum"1,"kern"1;-o-font-feature-settings:"dlig"1,"liga"1,"lnum"1,"kern"1}h1{text-indent:-2px;letter-spacing:-1px;font-size:2.2rem}h2{letter-spacing:0;font-size:2rem}h3{letter-spacing:-.6px;font-size:1.8rem}h4{font-size:1.6rem}h5{font-size:1.54rem}h6{font-size:1.43rem}a{color:#002ead;text-decoration:none}a:hover{color:#111;text-decoration:underline}p,ul,ol,dl{margin:0 0 2.5rem 0;text-rendering:geometricPrecision;-webkit-font-feature-settings:"liga"1,"onum"1,"kern"1;-moz-font-feature-settings:"liga"1,"onum"1,"kern"1;-o-font-feature-settings:"liga"1,"onum"1,"kern"1}ol,ul{padding-left:2em}ol ol,ul ul,ul ol,ol ul{margin:0 0 .4em 0;padding-left:2em}dl dt{float:left;clear:left;overflow:hidden;margin-bottom:1em;width:180px;text-align:right;-o-text-overflow:ellipsis;text-overflow:ellipsis;white-space:nowrap;font-weight:700}dl dd{margin-bottom:1em;margin-left:200px}li{margin:.4em 0}li li{margin:0}hr{display:block;margin:1.75em 0;padding:0;height:1px;border:0;border-top:#efefef 1px solid}blockquote{-webkit-box-sizing:border-box;box-sizing:border-box;margin:1.75em 0 1.75em 0;padding:0 0 0 1.75em;border-left:#002ead .4em solid;-moz-box-sizing:border-box}blockquote p{margin:.8em 0;font-style:italic}blockquote small{display:inline-block;margin:.8em 0 .8em 1.5em;color:#ccc;font-size:.9em}blockquote small:before{content:""}blockquote cite{font-weight:700}blockquote cite a{font-weight:normal}mark{background-color:#fdffb6}code,tt{padding:1px 3px;background:#eeeef0;white-space:pre-wrap;font-family:Inconsolata,monospace,sans-serif;font-size:.85em;font-feature-settings:"liga"0;-webkit-font-feature-settings:"liga"0;-moz-font-feature-settings:"liga"0}pre{overflow:auto;-webkit-box-sizing:border-box;box-sizing:border-box;margin:0 0 1.75em 0;padding:10px;width:100%;border:#eeeef0 1px solid;background:#eeeef0;white-space:pre;font-family:Inconsolata,monospace,sans-serif;font-size:.9em;-moz-box-sizing:border-box}pre code,pre tt{padding:0;border:none;background:transparent;white-space:pre-wrap;font-size:inherit}kbd{display:inline-block;margin-bottom:.4em;padding:1px 8px;border:#ccc 1px solid;background:#f4f4f4;-webkit-box-shadow:0 1px 0 rgba(0,0,0,.2),0 1px 0 0#fff inset;-moz-box-shadow:0 1px 0 rgba(0,0,0,.2),0 1px 0 0#fff inset;box-shadow:0 1px 0 rgba(0,0,0,.2),0 1px 0 0#fff inset;color:#666;text-shadow:#fff 0 1px 0;font-size:.9em;font-weight:700}table{-webkit-box-sizing:border-box;box-sizing:border-box;margin:1em 0;max-width:100%;width:100%;white-space:nowrap;background-color:transparent;-moz-box-sizing:border-box}table th,table td{padding:8px;border-top:#efefef 1px solid;vertical-align:top;text-align:left;line-height:20px}table th{color:#000}table caption+thead tr:first-child th,table caption+thead tr:first-child td,table colgroup+thead tr:first-child th,table colgroup+thead tr:first-child td,table thead:first-child tr:first-child th,table thead:first-child tr:first-child td{border-top:0}table tbody+tbody{border-top:#efefef 2px solid}table table table{background-color:#fff}table tbody>tr:nth-child(odd)>td,table tbody>tr:nth-child(odd)>th{background-color:#f6f6f6}table.plain tbody>tr:nth-child(odd)>td,table.plain tbody>tr:nth-child(odd)>th{background:transparent}iframe,amp-iframe,.fluid-width-video-wrapper{display:block;margin:1.75em 0}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper amp-iframe{margin:0}textarea,select,input{margin:0 0 5px 0;padding:6px 9px;width:260px;outline:0;border:#e7eef2 1px solid;background:#fff;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;font-family:"Lato",sans-serif;font-size:1.6rem;line-height:1.4em;font-weight:100;-webkit-appearance:none}textarea{min-width:250px;min-height:80px;max-width:340px;width:100%;height:auto}input[type="text"]:focus,input[type="email"]:focus,input[type="search"]:focus,input[type="tel"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="number"]:focus,input[type="date"]:focus,input[type="month"]:focus,input[type="week"]:focus,input[type="time"]:focus,input[type="datetime"]:focus,input[type="datetime-local"]:focus,textarea:focus{outline:none;outline-width:0;border:#bbc7cc 1px solid;background:#fff}select{width:270px;height:30px;line-height:30px}.clearfix:before,.clearfix:after{content:" ";display:table}.clearfix:after{clear:both}.clearfix{zoom:1}.main-header{position:relative;display:table;overflow:hidden;box-sizing:border-box;width:100%;height:50px;background:#0a0a23 no-repeat center center;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;text-align:left;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;height:38px}.blog-title,.content{margin:auto;max-width:600px}.blog-title{height:52px}.blog-title amp-img{height:24px;margin-top:7px;margin-bottom:7px}.blog-title a{display:block;padding-right:16px;padding-left:16px;height:50px;color:#fff;text-decoration:none;font-family:"Lato",sans-serif;font-size:16px;line-height:50px;font-weight:600}.content{background:#fff;padding-top:15px}.post{position:relative;margin-top:0;margin-right:16px;margin-left:16px;padding-bottom:0;max-width:100%;border-bottom:#ebf2f6 1px solid;word-wrap:break-word;font-size:.95em;line-height:1.65em}.post-header{margin-bottom:1rem}.post-title{margin-bottom:0}.post-title a{text-decoration:none}.post-meta{display:block;margin:3px 0 0 0;color:#0a0a23;font-size:1.3rem;line-height:2.2rem}.post-meta a{color:#0a0a23;text-decoration:none}.post-meta a:hover{text-decoration:underline}.post-meta .author{margin:0;font-size:1.3rem;line-height:1.3em}.post-date{display:inline-block;text-transform:uppercase;white-space:nowrap;font-size:line-height:1.2em}.post-image{margin:0;padding-top:3rem;padding-bottom:30px;border-top:1px#e8e8e8 solid}.post-content amp-img,.post-content amp-anim{position:relative;left:50%;display:block;padding:0;min-width:0;max-width:112%;width:-webkit-calc(100% + 32px);width:-moz-calc(100% + 32px);width:calc(100% + 32px);height:auto;-moz-transform:translatex(-50%);-o-transform:translatex(-50%);transform:translatex(-50%);-webkit-transform:translatex(-50%);-ms-transform:translatex(-50%)}.footnotes{font-size:1.3rem;line-height:1.6em;font-style:italic}.footnotes li{margin:.6rem 0}.footnotes p{margin:0}.footnotes p a:last-child{text-decoration:none}.site-footer{position:relative;margin:0 auto 20px auto;padding:1rem 15px;max-width:600px;color:rgba(0,0,0,.5);font-family:"Lato",sans-serif;font-size:1.1rem;line-height:1.75em}.site-footer a{color:rgba(0,0,0,.5);text-decoration:none;font-weight:bold}.site-footer a:hover{border-bottom:#bbc7cc 1px solid}.poweredby{display:block;float:right;width:45%;text-align:right}.copyright{display:block;float:left;width:45%}.medium-migrated-article>p:first-child{text-align:center}.medium-migrated-article>figure:first-of-type{display:none}.medium-migrated-article>h1{display:none}.hidden{display:none}.donation_btn{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-webkit-flex-direction:row;-moz-box-orient:horizontal;-moz-box-direction:normal;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;background-color:#ffc300;border-color:#ffc300;color:black;text-decoration:none;padding:10px;font-size:20px;font-weight:bold}.donation_btn:hover{background-color:#ffbf00;border-color:#ffbf00}'
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/layouts/index.tsx




//import FigureLayout from './FigureLayout'


;// CONCATENATED MODULE: ./src/pages/_app.tsx








const DynamicNextprogress = dynamic_default()(()=>__webpack_require__.e(/* import() */ 595).then(__webpack_require__.bind(__webpack_require__, 3595)), {
    loadableGenerated: {
        modules: [
            "_app.tsx -> " + "../components/layouts/Nextprogress"
        ]
    },
    ssr: false
});
const App = ({ Component , pageProps  })=>{
    const isAmp = (0,amp_namespaceObject.useAmp)();
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: isAmp ? /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_next_themes_.ThemeProvider, {
            attribute: "class",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(DynamicNextprogress, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(NavBar, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(FooterApp, {})
            ]
        })
    });
};
/* harmony default export */ const _app = ((0,external_next_i18next_.appWithTranslation)(App));
const config = {
    amp: "hybrid"
};


/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 1162:
/***/ ((module) => {

"use strict";
module.exports = require("next-themes");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 8890:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-progressbar");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,810], () => (__webpack_exec__(5126)));
module.exports = __webpack_exports__;

})();