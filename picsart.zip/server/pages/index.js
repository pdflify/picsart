"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 4251:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
// EXTERNAL MODULE: ./src/components/Icons/AppFigure.tsx + 1 modules
var AppFigure = __webpack_require__(3734);
;// CONCATENATED MODULE: ./src/components/HomePage/HeaderApp.tsx





function HeaderApp() {
    const { t  } = (0,external_react_i18next_.useTranslation)("common");
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "py-6 lg:py-12 flex items-center px-6",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-center mx-auto inline-block",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "z-1 relative inline-flex justify-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(AppFigure["default"], {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl lg:text-6xl leading-tight max-w-3xl font-bold tracking-tight mt-6 mx-auto",
                        children: t("title")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "max-w-3xl mx-auto lg:text-xl text-gray-600 mt-3 leading-normal font-light dark:font-normal dark:text-black",
                        children: t("summary")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "max-w-3xl mx-auto lg:text-xl text-gray-600 mt-3 leading-normal font-light",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: t("summary-A")
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "max-w-3xl mx-auto lg:text-xl text-gray-600 mt-3 leading-normal font-light",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                children: [
                                    t("current-version"),
                                    ":"
                                ]
                            }),
                            " 20.9.4"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "py-2 z-1 px-6 mt-8 rounded-full gradient-border-badge relative bg-transparent inline-flex items-center justify-center ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "z-10 text-sm lg:text-base bg-clip-text text-transparent bg-gradient-to-r from-[#9867f0] to-[#ed4e50] font-semibold relative -top-px",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: t("downloadpage"),
                                children: [
                                    " ",
                                    t("download"),
                                    " APK"
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/components/HomePage/TocPage.tsx




function TocPage() {
    const { t  } = (0,external_react_i18next_.useTranslation)("common");
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "contener lg:px-48",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "lg:text-xl text-gray-600 leading-normal divide-y divide-gray-200 dark:divide-gray-800 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "p-2 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                children: "Contents"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "p-2 text-center text-[#9867f0]",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "#about_picsart_photo_editor",
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                    i18nKey: "article.about.h2"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "p-2 text-center text-[#9867f0]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "#about_picsart_photo_editor",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.mod.h2"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "p-2 text-center text-[#9867f0]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "#about_picsart_photo_editor",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.gold.h2"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "p-2 text-center text-[#9867f0]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "#about_picsart_photo_editor",
                            children: " About PicsArt Photo Editor"
                        })
                    })
                ]
            })
        })
    });
} //}

;// CONCATENATED MODULE: ./src/components/HomePage/AppInfo.tsx



function AppInfo() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "flex justify-center my-6",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: "lg:text-xl text-gray-600 leading-normal font-light divide-y divide-gray-200 dark:divide-gray-800 lg:w-1/2",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "p-2 ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.name"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "ml-16",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.name"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "p-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.genres"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "ml-14",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.genres"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "p-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.Version"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "ml-14",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.Version"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "p-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("b", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                    i18nKey: "article.download.info.install"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "ml-16",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.install"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "p-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("b", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                    i18nKey: "article.download.info.developer"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "ml-8",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.developer"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "p-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("b", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                    i18nKey: "article.download.info.requires"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "ml-14",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.requires"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "p-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.size"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "ml-20",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.size"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "p-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("b", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                    i18nKey: "article.download.info.mod-features"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "ml-1",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.mod-features"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    className: "p-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.Updated"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "ml-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.Updated"
                            })
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/components/HomePage/ArticlePage.tsx






const DynamicToolBar = dynamic_default()(()=>__webpack_require__.e(/* import() */ 145).then(__webpack_require__.bind(__webpack_require__, 5145)), {
    loadableGenerated: {
        modules: [
            "..\\components\\HomePage\\ArticlePage.tsx -> " + "../Icons/ToolBar"
        ]
    },
    suspense: true
});
const DynamicArticleTab = dynamic_default()(()=>__webpack_require__.e(/* import() */ 2).then(__webpack_require__.bind(__webpack_require__, 2002)), {
    loadableGenerated: {
        modules: [
            "..\\components\\HomePage\\ArticlePage.tsx -> " + "./ArticleTab"
        ]
    },
    suspense: true
});
const DynamicAppFigure = dynamic_default()(()=>Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 3734)), {
    loadableGenerated: {
        modules: [
            "..\\components\\HomePage\\ArticlePage.tsx -> " + "../Icons/AppFigure"
        ]
    },
    suspense: true
});
const DynamicWindowsIcon = dynamic_default()(()=>__webpack_require__.e(/* import() */ 282).then(__webpack_require__.bind(__webpack_require__, 6282)), {
    loadableGenerated: {
        modules: [
            "..\\components\\HomePage\\ArticlePage.tsx -> " + "../Icons/WindowsIcon"
        ]
    },
    suspense: true
});
const DynamicWindowsFeature = dynamic_default()(()=>__webpack_require__.e(/* import() */ 277).then(__webpack_require__.bind(__webpack_require__, 2277)), {
    loadableGenerated: {
        modules: [
            "..\\components\\HomePage\\ArticlePage.tsx -> " + "../Icons/WindowsFeature"
        ]
    },
    suspense: true
});
const KeyFeatures = [
    {
        id: "a",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.a"
        })
    },
    {
        id: "b",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.b"
        })
    },
    {
        id: "c",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.c"
        })
    },
    {
        id: "d",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.d"
        })
    },
    {
        id: "e",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.e"
        })
    },
    {
        id: "f",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.f"
        })
    },
    {
        id: "g",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.g"
        })
    },
    {
        id: "h",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.h"
        })
    },
    {
        id: "i",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.i"
        })
    },
    {
        id: "j",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.j"
        })
    },
    {
        id: "k",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.k"
        })
    },
    {
        id: "l",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.l"
        })
    },
    {
        id: "m",
        name: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
            i18nKey: "article.keyf.list.m"
        })
    }
];
function ArticlePage() {
    const { t  } = (0,external_react_i18next_.useTranslation)("common");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DynamicArticleTab, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "lg:px-44 px-4 max-w-3xl mx-auto lg:text-xl text-gray-600 text-center leading-normal",
                itemProp: "headline",
                children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                        i18nKey: "article.keyf.h2"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "py-2 lg:py-12 text-center px-6 ",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "z-1 relative inline-flex ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(DynamicToolBar, {})
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "contener lg:px-48 px-3 lg:text-xl text-gray-600 leading-normal font-light",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    itemProp: "text",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                        i18nKey: "article.keyf.p"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "contener lg:px-56 px-6 mt-4 lg:text-xl font-light",
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "list-disc list-outside",
                    children: KeyFeatures.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                            itemProp: "name",
                            children: item.name
                        }, item.id))
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "lg:px-44 px-4 mt-4 max-w-3xl mx-auto lg:text-xl text-gray-600 text-center leading-normal",
                itemProp: "headline",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                    i18nKey: "article.howto.h2"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "contener lg:px-48 px-3 mt-2 lg:text-xl text-gray-600 leading-normal font-light",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    itemProp: "text",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                        i18nKey: "article.howto.p"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "contener lg:px-56 px-6 mt-4 lg:text-xl font-light",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ol", {
                    className: "list-decimal list-outside",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            itemProp: "name",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.howto.a"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            itemProp: "name",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.howto.b"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            itemProp: "name",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.howto.c"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            itemProp: "name",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.howto.d"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "contener lg:px-48 px-3 mt-2 lg:text-xl text-gray-600 leading-normal font-light",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    itemProp: "text",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                        i18nKey: "article.howto.e"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "lg:px-44 px-4 mt-4 max-w-3xl mx-auto lg:text-xl text-gray-600 text-center leading-normal",
                itemProp: "headline",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                    i18nKey: "article.download.h2"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "contener lg:px-48 px-3 mt-2 lg:text-xl text-gray-600 leading-normal font-light",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-center items-center mx-auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "z-1 relative inline-flex justify-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Suspense, {
                                fallback: `Loading...`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DynamicAppFigure, {})
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.download.p"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AppInfo, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "contener lg:px-48 px-3 mt-2 lg:text-xl text-gray-600 leading-normal font-light",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.download.note"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "py-2 z-1 px-6 mt-8 rounded-full gradient-border-badge relative bg-transparent inline-flex items-center justify-center ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "z-10 text-sm lg:text-base bg-clip-text text-transparent bg-gradient-to-r from-[#9867f0] to-[#ed4e50] font-semibold relative -top-px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.download.info.info.download"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "lg:px-44 px-4 mt-4 max-w-3xl mx-auto lg:text-xl text-gray-600 text-center leading-normal",
                itemProp: "headline",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                    i18nKey: "article.windows.h2"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "contener lg:px-48 px-3 mt-2 lg:text-xl text-gray-600 leading-normal font-light",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-center items-center mx-auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "z-1 relative inline-flex justify-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Suspense, {
                                fallback: `Loading...`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DynamicWindowsIcon, {})
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.windows.p"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.windows.p2"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-2 text-center items-center mx-auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "z-1 relative inline-flex justify-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Suspense, {
                                fallback: `Loading...`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DynamicWindowsFeature, {})
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        className: "my-2 mt-4 p-3 shadow-2xl bg-slate-800 rounded-3xl text-white",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.windows.q"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        className: "my-2 p-3 shadow-2xl bg-slate-800 rounded-full text-white",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.windows.q2"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        className: "my-2 p-3 shadow-2xl bg-slate-800 rounded-3xl text-white",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.windows.q3"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "py-2 z-1 px-6 mt-8 rounded-full gradient-border-badge relative bg-transparent inline-flex items-center justify-center ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "z-10 text-sm lg:text-base bg-clip-text text-transparent bg-gradient-to-r from-[#9867f0] to-[#ed4e50] font-semibold relative -top-px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                                i18nKey: "article.windows.download"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "lg:px-44 px-4 mt-8 max-w-3xl mx-auto lg:text-xl text-gray-600 text-center leading-normal",
                itemProp: "headline",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                    i18nKey: "article.opinion.h2"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "contener lg:px-48 px-3 mt-2 lg:text-xl text-gray-600 leading-normal font-light",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.opinion.p"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.opinion.p2"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        className: "my-2 mt-4 p-3 shadow-2xl bg-slate-800 rounded-3xl text-white",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.opinion.q"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        className: "my-2 p-3 shadow-2xl bg-slate-800 rounded-full text-white",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.opinion.q2"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        itemProp: "text",
                        className: "my-2 p-3 shadow-2xl bg-slate-800 rounded-3xl text-white",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_i18next_.Trans, {
                            i18nKey: "article.opinion.q3"
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/HomePage/PicsArtHome.tsx







const DynamicEditingBar = dynamic_default()(()=>__webpack_require__.e(/* import() */ 26).then(__webpack_require__.bind(__webpack_require__, 5026)), {
    loadableGenerated: {
        modules: [
            "..\\components\\HomePage\\PicsArtHome.tsx -> " + "../Icons/EditingBar"
        ]
    },
    suspense: true
});
class PicsArtHome extends external_react_.Component {
    render() {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(HeaderApp, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(TocPage, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Suspense, {
                    fallback: `Loading...`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(DynamicEditingBar, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ArticlePage, {})
            ]
        });
    }
}
/* harmony default export */ const HomePage_PicsArtHome = (PicsArtHome);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./src/components/HomePage/MetaData.tsx




const MetaData = ()=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("title", {
                children: t("title")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: t("dec"),
                name: "description"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "canonical",
                href: `${"http://localhost:3000"}${t("canonical")}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "alternate",
                hrefLang: "x-default",
                href: `${"http://localhost:3000"}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "alternate",
                hrefLang: "en",
                href: `${"http://localhost:3000"}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "alternate",
                hrefLang: "hi",
                href: `${"http://localhost:3000"}/hi`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: `${"http://localhost:3000"}${t("canonical")}`,
                property: "og:url"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: `${"http://localhost:3000"}/img/PicsArt_Og.webp`,
                property: "og:image",
                name: "twitter:image",
                itemProp: "image primaryImageOfPage"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: t("title"),
                name: "twitter:title",
                property: "og:title",
                itemProp: "name"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: t("dec"),
                name: "twitter:description",
                property: "og:description",
                itemProp: "description"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: t("updatedAt"),
                property: "article:published_time"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: t("createdAt"),
                property: "article:published_time"
            })
        ]
    });
};
/* harmony default export */ const HomePage_MetaData = (MetaData);

;// CONCATENATED MODULE: ./src/components/HomePage/index.tsx




;// CONCATENATED MODULE: ./src/pages/index.tsx




const Home = (_Props)=>{
    //const router = useRouter()
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_MetaData, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_PicsArtHome, {})
        ]
    });
};
// or getServerSideProps: GetServerSideProps<Props> = async ({ locale })
const getStaticProps = async ({ locale  })=>({
        props: {
            ...await (0,serverSideTranslations_.serverSideTranslations)(locale ?? "en", [
                "common"
            ])
        }
    });
/* harmony default export */ const pages = (Home);


/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9709:
/***/ ((module) => {

module.exports = require("react-i18next");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,810,675,734], () => (__webpack_exec__(4251)));
module.exports = __webpack_exports__;

})();