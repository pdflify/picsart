"use strict";
(() => {
var exports = {};
exports.id = 715;
exports.ids = [715];
exports.modules = {

/***/ 3325:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ download),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
// EXTERNAL MODULE: ./src/components/Icons/AppFigure.tsx + 1 modules
var AppFigure = __webpack_require__(3734);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
;// CONCATENATED MODULE: ./src/components/DownloadPage/HeaderApp.tsx





const DynamicDownloadLink = dynamic_default()(()=>Promise.all(/* import() */[__webpack_require__.e(676), __webpack_require__.e(664), __webpack_require__.e(962)]).then(__webpack_require__.bind(__webpack_require__, 5962)), {
    loadableGenerated: {
        modules: [
            "..\\components\\DownloadPage\\HeaderApp.tsx -> " + "@/components/DownloadPage/DownloadLink"
        ]
    },
    ssr: false
});
function HeaderApp() {
    const { t  } = (0,external_react_i18next_.useTranslation)("download");
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "py-6 lg:py-12 flex items-center px-6",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-center mx-auto inline-block",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "z-1 relative inline-flex justify-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(AppFigure["default"], {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl lg:text-6xl leading-tight max-w-3xl font-bold tracking-tight mt-6 mx-auto",
                        children: t("title")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "max-w-3xl mx-auto lg:text-xl text-gray-600 mt-3 leading-normal font-light dark:font-normal dark:text-black",
                        children: t("summary")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "max-w-3xl mx-auto lg:text-xl text-gray-600 mt-3 leading-normal font-light",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: t("summary-A")
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "max-w-3xl mx-auto lg:text-xl text-gray-600 mt-3 leading-normal font-light",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                children: [
                                    t("current-version"),
                                    ":"
                                ]
                            }),
                            " 20.9.4"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "py-2 z-1 px-6 mt-8 rounded-full gradient-border-badge relative bg-transparent inline-flex items-center justify-center ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "z-10 text-sm lg:text-base bg-clip-text text-transparent bg-gradient-to-r from-[#9867f0] to-[#ed4e50] font-semibold relative -top-px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(DynamicDownloadLink, {})
                        })
                    })
                ]
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/components/DownloadPage/AboutPage.tsx



function AboutPage() {
    const { t  } = (0,external_react_i18next_.useTranslation)("download");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "lg:px-44 px-4 mt-8 max-w-3xl mx-auto lg:text-xl text-gray-600 text-center leading-normal",
                itemProp: "headline",
                children: t("h2")
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "contener lg:px-48 px-3 mt-2 lg:text-xl text-gray-600 leading-normal font-light",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        itemProp: "text",
                        children: [
                            " ",
                            t("p"),
                            " "
                        ]
                    }),
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("b", {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        itemProp: "text",
                        children: [
                            " ",
                            t("p2"),
                            " "
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        itemProp: "text",
                        children: [
                            " ",
                            t("p3"),
                            " "
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        itemProp: "text",
                        className: "my-2 mt-4 p-3 shadow-2xl bg-slate-800 rounded-3xl text-white",
                        children: [
                            t("disclaimer"),
                            " "
                        ]
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./src/components/DownloadPage/MetaData.tsx




const MetaData = ()=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("download");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                children: [
                    t("title"),
                    " मुफ्त डाउनलोड"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: t("dec"),
                name: "description"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "canonical",
                href: `${"http://localhost:3000"}${t("canonical")}/download`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "alternate",
                hrefLang: "x-default",
                href: `${"http://localhost:3000"}/download`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "alternate",
                hrefLang: "en",
                href: `${"http://localhost:3000"}/download`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "alternate",
                hrefLang: "hi",
                href: `${"http://localhost:3000"}/hi/download`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: `${"http://localhost:3000"}${t("canonical")}`,
                property: "og:url"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: `${"http://localhost:3000"}/img/PicsArt_Og.webp`,
                property: "og:image",
                name: "twitter:image",
                itemProp: "image primaryImageOfPage"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: `${t("title")}  मुफ्त डाउनलोड`,
                name: "twitter:title",
                property: "og:title",
                itemProp: "name"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: t("dec"),
                name: "twitter:description",
                property: "og:description",
                itemProp: "description"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: t("updatedAt"),
                property: "article:published_time"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                content: t("createdAt"),
                property: "article:published_time"
            })
        ]
    });
};
/* harmony default export */ const DownloadPage_MetaData = (MetaData);

;// CONCATENATED MODULE: ./src/pages/download/index.tsx







const DownloadPage = (_Props)=>{
    //const router = useRouter()
    const { t  } = (0,external_next_i18next_.useTranslation)("download");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DownloadPage_MetaData, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HeaderApp, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(AboutPage, {})
        ]
    });
};
// or getServerSideProps: GetServerSideProps<Props> = async ({ locale })
const getStaticProps = async ({ locale  })=>({
        props: {
            ...await (0,serverSideTranslations_.serverSideTranslations)(locale ?? "en", [
                "download"
            ])
        }
    });
/* harmony default export */ const download = (DownloadPage);


/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9709:
/***/ ((module) => {

module.exports = require("react-i18next");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [810,675,734], () => (__webpack_exec__(3325)));
module.exports = __webpack_exports__;

})();